#include "cpu_kernels.h"
#include <math.h>
#include <stdio.h>

#define GAUSSIAN_KERNEL_SIZE 3
#define GAUSSIAN_NORM 16.0f

static const float gaussianKernel[GAUSSIAN_KERNEL_SIZE][GAUSSIAN_KERNEL_SIZE] = {
    {1.0f, 2.0f, 1.0f},
    {2.0f, 4.0f, 2.0f},
    {1.0f, 2.0f, 1.0f}
};

static int clampInt(int value, int minVal, int maxVal) {
    if (value < minVal) return minVal;
    if (value > maxVal) return maxVal;
    return value;
}

static void rgbToHsvSingle(unsigned char r, unsigned char g, unsigned char b,
                           float *h, float *s, float *v) {
    float norm_r = r / 255.0f;
    float norm_g = g / 255.0f;
    float norm_b = b / 255.0f;

    float max_value = fmaxf(norm_r, fmaxf(norm_g, norm_b));
    float min_value = fminf(norm_r, fminf(norm_g, norm_b));

    *v = max_value;

    if (max_value == 0.0f) {
        *s = 0.0f;
    } else {
        *s = (max_value - min_value) / max_value;
    }

    if (max_value - min_value == 0.0f) {
        *h = 0.0f;
    } else if (norm_r == max_value) {
        *h = ((norm_g - norm_b) / (max_value - min_value)) * 60.0f;
        if (*h < 0.0f) *h += 360.0f;
    } else if (norm_g == max_value) {
        *h = ((norm_b - norm_r) / (max_value - min_value)) * 60.0f + 120.0f;
    } else {
        *h = ((norm_r - norm_g) / (max_value - min_value)) * 60.0f + 240.0f;
    }

    if (*h < 0.0f) *h += 360.0f;
    if (*h >= 360.0f) *h -= 360.0f;
}

void rgbToHsvCPU(unsigned char *input_img, float *output_img, int height, int width) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int pixel_index = (y * width + x) * 3;

            unsigned char r = input_img[pixel_index];
            unsigned char g = input_img[pixel_index + 1];
            unsigned char b = input_img[pixel_index + 2];

            float h, s, v;
            rgbToHsvSingle(r, g, b, &h, &s, &v);

            output_img[pixel_index]     = h;
            output_img[pixel_index + 1] = s;
            output_img[pixel_index + 2] = v;
        }
    }
}

void filterRedCPU(float *input_img, unsigned char *output_img, int height, int width) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int pixel_index = (y * width + x) * 3;

            float h = input_img[pixel_index];
            float s = input_img[pixel_index + 1];
            float v = input_img[pixel_index + 2];

            int isRedHue = ((h >= 0.0f && h <= 10.0f) || (h >= 350.0f && h <= 360.0f));
            int isSaturated = (s > 0.3f);
            int isBright = (v > 0.3f);

            if (isRedHue && isSaturated && isBright) {
                output_img[y * width + x] = 255;
            } else {
                output_img[y * width + x] = 0;
            }
        }
    }
}

void gaussianSmoothCPU(unsigned char *input_img, unsigned char *output_img, int height, int width) {
    int half = GAUSSIAN_KERNEL_SIZE / 2;

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            float sum = 0.0f;

            for (int ky = -half; ky <= half; ky++) {
                for (int kx = -half; kx <= half; kx++) {
                    int neighbor_x = clampInt(x + kx, 0, width - 1);
                    int neighbor_y = clampInt(y + ky, 0, height - 1);

                    int neighbor_index = neighbor_y * width + neighbor_x;
                    float weight = gaussianKernel[ky + half][kx + half];

                    sum += input_img[neighbor_index] * weight;
                }
            }

            output_img[y * width + x] = (unsigned char)(sum / GAUSSIAN_NORM);
        }
    }
}